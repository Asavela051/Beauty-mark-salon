﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Public Class Form9
    Dim connectionString As String = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub txtDelete_TextChanged(sender As Object, e As EventArgs) Handles txtDelete.TextChanged

    End Sub

    Private Sub btnDELETE_Click(sender As Object, e As EventArgs) Handles btnDELETE.Click
        Dim recordID As String = txtDelete.Text

        ' Ensure that the TextBox is not empty
        If String.IsNullOrWhiteSpace(recordID) Then
            MessageBox.Show("Please enter a valid Username.")
            Return
        End If

        ' Call the delete method
        DeleteRecord(recordID)
    End Sub
    Private Sub DeleteRecord(ByVal recordID As String)
        ' SQL delete query
        Dim query As String = "DELETE FROM Appointment WHERE CustUsername = @CustUsername"

        ' Using OleDbConnection and OleDbCommand to execute the delete command
        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                ' Add the ID parameter to prevent SQL injection
                command.Parameters.AddWithValue("@CustUsername", recordID)

                Try
                    ' Open the connection
                    connection.Open()

                    ' Execute the delete command
                    Dim rowsAffected As Integer = command.ExecuteNonQuery()

                    ' Check if the delete operation was successful
                    If rowsAffected > 0 Then
                        MessageBox.Show("Record deleted successfully.")
                    Else
                        MessageBox.Show("No record found with the given CustUsername.")
                    End If

                Catch ex As Exception

                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnBACK_Click(sender As Object, e As EventArgs) Handles btnBACK.Click
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnEXIT_Click(sender As Object, e As EventArgs) Handles btnEXIT.Click
        Me.Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
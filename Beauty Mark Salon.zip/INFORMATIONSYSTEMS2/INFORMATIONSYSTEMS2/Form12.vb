﻿Imports System.Data.OleDb
Imports System.Data
Public Class Form12
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub btnConf_Click(sender As Object, e As EventArgs) Handles btnConf.Click
        Dim newPass As String = txtNew.Text
        Dim oldPass As String = txtNew.Text

        UpdateRecord(newPass, oldPass)

    End Sub
    Private Sub UpdateRecord(ByVal recordID As String, ByVal newName As String)
        ' SQL update query
        Dim query As String = "UPDATE Employee SET  EmpPassword = @EmpPassword WHERE EmpUsername = @EmpUsername"

        ' Using OleDbConnection and OleDbCommand to execute the update command
        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                ' Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@EmpPassword", newName)
                command.Parameters.AddWithValue("@EmpUsername", recordID)

                Try
                    ' Open the connection
                    connection.Open()

                    ' Execute the update command
                    Dim rowsAffected As Integer = command.ExecuteNonQuery()

                    ' Check if the update operation was successful
                    If rowsAffected > 0 Then
                        MessageBox.Show("Password updated successfully.")
                    Else
                        MessageBox.Show("No record found with the given ID.")
                    End If

                Catch ex As Exception
                    ' Handle potential errors
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub txtNew_TextChanged(sender As Object, e As EventArgs) Handles txtNew.TextChanged

    End Sub

    Private Sub txtOld_TextChanged(sender As Object, e As EventArgs) Handles txtOld.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
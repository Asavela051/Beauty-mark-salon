﻿Imports System.Data
Imports System.Data.OleDb
Public Class Form2
    ' Correct the connection string as per your database file location
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"

    Private Function IsValidLogin(ByVal username As String, ByVal password As String) As Boolean
        ' Define the SQL query to check the user credentials
        Dim query As String = "SELECT * FROM Employee WHERE EmpUsername = @username AND EmpPassword = @password"

        ' Create the connection object
        Using connection As New OleDbConnection(connectionString)
            ' Create the command object with the query and connection
            Using command As New OleDbCommand(query, connection)
                ' Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@username", username)
                command.Parameters.AddWithValue("@password", password)

                Try
                    ' Open the connection to the database
                    connection.Open()

                    ' Execute the query and get the result
                    Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

                    ' If result is greater than 0, the credentials are valid
                    If result > 0 Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                    Return False
                Finally
                    ' Close the connection
                    connection.Close()
                End Try

            End Using
        End Using
    End Function



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnSign_Click_1(sender As Object, e As EventArgs) Handles btnSign.Click
        ' Get the username and password from the textboxes
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Check if the Employee radio button is checked
        If radEmp.Checked = True Then
            If IsValidLogin(username, password) Then
                MessageBox.Show("Logged in successfully!")
                Form7.Show()
                Me.Hide()
            Else
                MessageBox.Show("Invalid credentials!")
                txtUsername.Clear()
                txtPassword.Clear()
            End If

        ElseIf radCust.Checked = True Then
            If CuctValidLog(username, password) Then
                MessageBox.Show("Logged in successfully!")
                Form6.Show()
                Me.Hide()
            Else
                MessageBox.Show("Invalid credentials!")
                txtUsername.Clear()
                txtPassword.Clear()

            End If
        End If


    End Sub
    Private Function CuctValidLog(ByVal custUser As String, ByVal custPass As String) As Boolean
        ' Define the SQL query to check the user credentials
        Dim query As String = "SELECT * FROM Customer WHERE CustUsername = @username AND CustPassword = @password"

        ' Create the connection object
        Using connection As New OleDbConnection(connectionString)
            ' Create the command object with the query and connection
            Using command As New OleDbCommand(query, connection)
                ' Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@username", custUser)
                command.Parameters.AddWithValue("@password", custPass)

                Try
                    ' Open the connection to the database
                    connection.Open()

                    ' Execute the query and get the result
                    Dim result As Integer = Convert.ToInt32(command.ExecuteScalar())

                    ' If result is greater than 0, the credentials are valid
                    If result > 0 Then
                        Return True
                    Else
                        Return False
                    End If
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                    Return False
                Finally
                    ' Close the connection
                    connection.Close()
                End Try

            End Using
        End Using
    End Function

    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Form10.Show()
        Me.Hide()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Form11.Show()
        Me.Hide()
    End Sub
End Class
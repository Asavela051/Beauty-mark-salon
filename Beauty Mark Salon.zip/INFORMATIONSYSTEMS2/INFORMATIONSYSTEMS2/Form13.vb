﻿Imports System.Data.OleDb

Public Class Form13
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    Private Sub LoadDataGridView()
        ' SQL query to select all data from a table, e.g., "Appointments"
        Dim query As String = "SELECT * FROM Employee"

        ' Create a connection to the database
        Using conn As New OleDbConnection(connectionString)
            ' Create an adapter to retrieve data from the database
            Dim adapter As New OleDbDataAdapter(query, conn)

            ' Create a DataTable to hold the retrieved data
            Dim dt As New DataTable()

            Try
                ' Open the connection
                conn.Open()

                ' Fill the DataTable with data from the Access table
                adapter.Fill(dt)

                ' Bind the DataTable to the DataGridView
                DataGridView1.DataSource = dt

            Catch ex As Exception
                ' Handle any errors that might occur
                MessageBox.Show("Error: " & ex.Message)
            Finally
                ' Close the connection
                conn.Close()
            End Try
        End Using
    End Sub

    Private Sub Form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDataGridView()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
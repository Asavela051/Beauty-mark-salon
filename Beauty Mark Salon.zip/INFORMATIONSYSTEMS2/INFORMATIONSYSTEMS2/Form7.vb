﻿Imports System.Data.OleDb
Imports System.Data
Public Class Form7
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()
    End Sub


    Private Sub LoadDataGridView()
        ' SQL query to select all data from a table, e.g., "Appointments"
        Dim query As String = "SELECT * FROM Appointment"

        ' Create a connection to the database
        Using conn As New OleDbConnection(connectionString)
            ' Create an adapter to retrieve data from the database
            Dim adapter As New OleDbDataAdapter(query, conn)

            ' Create a DataTable to hold the retrieved data
            Dim dt As New DataTable()

            Try
                ' Open the connection
                conn.Open()

                ' Fill the DataTable with data from the Access table
                adapter.Fill(dt)

                ' Bind the DataTable to the DataGridView
                DataGridView1.DataSource = dt

            Catch ex As Exception
                ' Handle any errors that might occur
                MessageBox.Show("Error: " & ex.Message)
            Finally
                ' Close the connection
                conn.Close()
            End Try
        End Using
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Form9.Show()
        Me.Hide()

    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        Form13.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form8.Show()
        Me.Hide()

    End Sub

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDataGridView()
    End Sub
End Class
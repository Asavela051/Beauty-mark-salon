﻿Imports System.Data
Imports System.Data.OleDb
Public Class Form5
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Dim name As String = txtName.Text
        Dim surname As String = txtSurname.Text
        Dim phone As String = txtPhone.Text
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text
        Dim email As String = txtEmail.Text
        Dim address As String = txtAddress.Text

        ' Call the function to insert data
        InsertData(name, surname, address, username, password, phone)
        Form6.Show()
        Me.Hide()
    End Sub
    Private Sub InsertData(name As String, surname As String, address As String, username As String, password As String, phone As String)
        Try
            Using conn As New OleDbConnection(connectionString)
                conn.Open()

                ' SQL Query to insert data into Users table
                Dim query As String = "INSERT INTO Customer ([CustName], [CustSurname], [CustPhone], [CustUsername], [CustPassword], [CustEmail], [CustAddress]) VALUES (@Name, @Surname, @Phone, @Username, @Password, @Email, @Address)"

                Using cmd As New OleDbCommand(query, conn)
                    ' Adding parameters to prevent SQL Injection
                    cmd.Parameters.AddWithValue("@Name", name)
                    cmd.Parameters.AddWithValue("@Surname", surname)
                    cmd.Parameters.AddWithValue("@Phone", address)
                    cmd.Parameters.AddWithValue("@Username", username)
                    cmd.Parameters.AddWithValue("@Password", password)
                    cmd.Parameters.AddWithValue("@email", phone)
                    cmd.Parameters.AddWithValue("@Address", phone)

                    ' Execute the query
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("You have registered successfully!")
            Form2.Show()
            Me.Hide()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        For Each c As Char In txtName.Text
            If Char.IsLetter(c) = False Then
                MsgBox("Name must have alphabetic letters only")
                txtName.Clear()
                txtName.Focus()
            End If
        Next
    End Sub

    Private Sub txtSurname_TextChanged(sender As Object, e As EventArgs) Handles txtSurname.TextChanged
        For Each c As Char In txtSurname.Text
            If Char.IsLetter(c) = False Then
                MsgBox("Surname must have alphabetic letters only")
                txtSurname.Clear()
                txtSurname.Focus()
            End If
        Next
    End Sub

    Private Sub txtPhone_TextChanged(sender As Object, e As EventArgs) Handles txtPhone.TextChanged
        If IsNumeric(txtPhone.Text) = False Then
            MessageBox.Show("Please enter numeric values!")
            txtPhone.Clear()
            txtPhone.Focus()
        End If
    End Sub
End Class
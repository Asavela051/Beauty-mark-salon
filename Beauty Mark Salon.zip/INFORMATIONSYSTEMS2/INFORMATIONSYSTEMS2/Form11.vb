﻿Imports System.Data
Imports System.Data.OleDb
Public Class Form11
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim user As String = txtUser.Text
        Dim pass As String = txtPass.Text
        If String.IsNullOrWhiteSpace(pass) OrElse String.IsNullOrWhiteSpace(user) Then
            MessageBox.Show("Please enter both Ussername and Password.")
            Return
        End If

        ' Call the update method
        UpdateRecord(user, pass)
    End Sub
    Private Sub UpdateRecord(ByVal recordID As String, ByVal newName As String)

        Dim query As String = "UPDATE Customer SET  CustPassword = @CustPassword WHERE CustUsername = @CustUsername"

        ' Using OleDbConnection and OleDbCommand to execute the update command
        Using connection As New OleDbConnection(connectionString)
            Using command As New OleDbCommand(query, connection)
                ' Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@CustPassword", newName)
                command.Parameters.AddWithValue("@CustUsername", recordID)

                Try
                    ' Open the connection
                    connection.Open()

                    ' Execute the update command
                    Dim rowsAffected As Integer = command.ExecuteNonQuery()

                    ' Check if the update operation was successful
                    If rowsAffected > 0 Then
                        MessageBox.Show("Password updated successfully.")
                    Else
                        MessageBox.Show("No record found with the given ID.")
                    End If

                Catch ex As Exception
                    ' Handle potential errors
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtPass_TextChanged(sender As Object, e As EventArgs) Handles txtPass.TextChanged

    End Sub

    Private Sub txtUser_TextChanged(sender As Object, e As EventArgs) Handles txtUser.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
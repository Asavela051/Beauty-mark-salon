﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Public Class Form10
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"

    Private Sub UpdateRecord(ByVal recordID As String, ByVal newName As String)
        ' SQL update query
        Dim query As String = "UPDATE Employee SET  EmpPassword = @EmpPassword WHERE EmpUsername = @EmpUsername"

        ' Using OleDbConnection and OleDbCommand to execute the update command
        Using connection As New OleDbConnection(connectionstring)
            Using command As New OleDbCommand(query, connection)
                ' Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@EmpPassword", newName)
                command.Parameters.AddWithValue("@EmpUsername", recordID)

                Try
                    ' Open the connection
                    connection.Open()

                    ' Execute the update command
                    Dim rowsAffected As Integer = command.ExecuteNonQuery()

                    ' Check if the update operation was successful
                    If rowsAffected > 0 Then
                        MessageBox.Show("Password updated successfully.")
                    Else
                        MessageBox.Show("No record found with the given ID.")
                    End If

                Catch ex As Exception
                    ' Handle potential errors
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim recordID As String = txtUsername.Text
        Dim newName As String = txtPassword.Text

        ' Ensure both text boxes are not empty
        If String.IsNullOrWhiteSpace(recordID) OrElse String.IsNullOrWhiteSpace(newName) Then
            MessageBox.Show("Please enter both Ussername and Password.")
            Return
        End If

        ' Call the update method
        UpdateRecord(recordID, newName)
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged

    End Sub

    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
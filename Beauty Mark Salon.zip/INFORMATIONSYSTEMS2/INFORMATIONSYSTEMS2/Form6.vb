﻿Imports System.Data
Imports System.Data.OleDb

Public Class Form6
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ADMIN\Documents\BeautyMark3.mdb"
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCustomerNames()
        cmbService.Items.Add("Chiskop")
        cmbService.Items.Add("Fade")
        cmbService.Items.Add("Hair treatment")
        cmbService.Items.Add("Hair colours")
        cmbService.Items.Add("Hairstyles")
        cmbService.Items.Add("Facials")
        cmbService.Items.Add("Nails")
        cmbService.Items.Add("Weave installation")
        cmbService.Items.Add("Carrot")
        cmbService.Items.Add("Braids")
        cmbService.Items.Add("Wash")
        cmbService.Items.Add("Trim")

        cmbAdditional.Items.Add("Hair colour")
        cmbAdditional.Items.Add("Pedicure")
        cmbAdditional.Items.Add("Makeup Application")
        cmbAdditional.Items.Add("Dye")
        cmbAdditional.Items.Add("Trim")
        cmbAdditional.Items.Add("None")

        cmbAppointTime.Items.Add("8:00 AM")
        cmbAppointTime.Items.Add("9:00 AM")
        cmbAppointTime.Items.Add("10:00 AM")
        cmbAppointTime.Items.Add("11:00 AM")
        cmbAppointTime.Items.Add("12:00 PM")
        cmbAppointTime.Items.Add("1:00 PM")
        cmbAppointTime.Items.Add("2:00 PM")
        cmbAppointTime.Items.Add("3:00 PM")
        cmbAppointTime.Items.Add("4:00 PM")
        cmbAppointTime.Items.Add("5:00 PM")
        cmbAppointTime.Items.Add("6:00 PM")
        cmbAppointTime.Items.Add("7:00 PM")

    End Sub

    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click

        Dim customerName As String = cmbUsername.SelectedItem.ToString()
        Dim serviceType As String = cmbService.SelectedItem.ToString()
        Dim appointmentDate As Date = DateTimePicker1.Value.Date
        Dim appointmentTime As String = cmbAppointTime.SelectedItem.ToString()
        Dim additional As String = cmbAdditional.SelectedItem.ToString()

        Dim query As String = "INSERT INTO Appointment (CustUsername, ServiceType, AppointDate, AppointTime, AdditionalService) " &
                              "VALUES (@CustomerName, @ServiceType, @AppointmentDate, @AppointmentTime, @AdditionalServices)"

        Using conn As New OleDbConnection(connectionString)
            Using cmd As New OleDbCommand(query, conn)

                cmd.Parameters.AddWithValue("@CustomerName", customerName)
                cmd.Parameters.AddWithValue("@ServiceType", serviceType)
                cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate)
                cmd.Parameters.AddWithValue("@AppointmentTime", appointmentTime)
                cmd.Parameters.AddWithValue("@AdditionalServices", additional)


                conn.Open()
                cmd.ExecuteNonQuery()
                conn.Close()
                MessageBox.Show("Appointment booked successfully!")
                cmbAdditional.Text = ""
                cmbAppointTime.Text = ""
                cmbService.Text = ""
                cmbUsername.Text = ""


            End Using
        End Using
    End Sub
    Private Sub LoadCustomerNames()
        Dim query As String = "SELECT CustUsername FROM Customer"
        Using conn As New OleDbConnection(connectionString)
            Using cmd As New OleDbCommand(query, conn)
                conn.Open()
                Using reader As OleDbDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        cmbUsername.Items.Add(reader("CustUsername").ToString())
                    End While
                End Using

                ' Close the connection
                conn.Close()
            End Using
        End Using
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnUpdateP_Click(sender As Object, e As EventArgs) Handles btnUpdateP.Click
        Form11.Show()
        Me.Hide()
    End Sub
End Class